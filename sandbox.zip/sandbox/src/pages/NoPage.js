import Header from "../components/Header"

export default function NoPage() {

    return(
        <div>
            <Header  words="There has been An error"/>
            <h2>there has been an error</h2>
        </div>
    )

}